﻿/**
 *	Constructor
 * @param {int} emiMin 	minimum X on the graph
 * @param {int} emiMax 	maximum X on the graph
 * @param {int} step 		incrementation step
 * @param {int} freq 		update frequency
 */
var GraphObject = function(emiMin, emiMax, exciMin, exciMax, step, freq, multi, type){
	this.myChart;
	this.lambdaEmiMin = emiMin;
	this.lambdaEmiMax = emiMax;
	this.lambdaExciMin = exciMin;
	this.lambdaExciMax = exciMax;
	this.stepGraph = step;
	this.frequency = freq;
	this.multiScan = multi;
	this.type = type;
	this.nbData = 0;
	this.ac = [];
	if(typeof graph.initialized == "undefined"){
		/**
		 *	Create and insert graph, with all X values
		 */
		GraphObject.prototype.insert = function() {
			var ctx = document.getElementById('graphe').getContext('2d');
		    //set x labels
		    var points = [];
		    if (this.type == 1) {
		    	var temp = parseInt(this.lambdaEmiMin);
		    	var nbpts = this.lambdaEmiMax-this.lambdaEmiMin;
		    	points.push(this.lambdaEmiMin);
		    }
		    else{
		    	var temp = parseInt(this.lambdaExciMin);
		    	var nbpts = this.lambdaExciMax-this.lambdaExciMin;
		    	points.push(this.lambdaExciMin);
		    }
		    
		    nbpts/=this.stepGraph;
		    for (var i = 0; i < nbpts-1; i++) {
		    	temp+=Number(this.stepGraph)
		    	points.push(temp);
		    }

		    //set empty datasets
		    var ds = []
		    for (var i = 1; i <= this.multiScan; i++) {
		    	var lab = "scan "+i;
		    	var ran = Math.floor(Math.random() * 6);
		    	var color = "rgba(";
		    	switch (ran){
		    		case 0:
		    		case 1:
		    			color +="238, "+Math.floor(Math.random() * (238-35) + 35)+",35, 0.2)";
		    		break;
		    		case 2:
		    			color += Math.floor(Math.random() * (238-35) + 35)+",238,35,0.2)";
		    		break;
		    		case 3:
		    			color += "35,238,"+Math.floor(Math.random() * (238-35) + 35)+",0.2)";
		    		break;
		    		case 4:
		    			color += "35,"+Math.floor(Math.random() * (238-35) + 35)+",238,0.2";
		    		break;
		    		case 5:
		    			color += Math.floor(Math.random() * (238-35) + 35)+",35,238,0.2";
		    		break;
		    		case 6:
		    		case 7:
		    			color += "238,35,"+Math.floor(Math.random() * (238-35) + 35)+",0.2";
		    		break;
		    	}
		    	ds.push({label: lab,hidden: false, backgroundColor: color});    
		    }
		    ds.push({label: 'Average', backgroundColor: "rgba("+Math.floor(Math.random() * 255)+","+Math.floor(Math.random() * 255)+","+Math.floor(Math.random() * 255)+",0.2)"});
		    //create chart
		    this.myChart = new Chart(ctx, {
		        type: 'line',
		        data: {
		        	labels: points,
		            datasets: ds
		        },
		        options: {
		            maintainAspectRatio: false,
		            legend: {
		            	display:true,
		            	position: 'top',
		            	onClick: function(e, legendItem) {
		            		//hide or unhide dataset on label click
							var index = legendItem.datasetIndex;
							var ci = this.chart;
							var meta = ci.getDatasetMeta(index);
							meta.hidden = meta.hidden === null? !ci.data.datasets[index].hidden : null;
							ci.data.datasets[index].hidden = !ci.data.datasets[index].hidden;
							//calculate average when hide or unhide dataset
							var nb = 0;
							for (var i = 0; i <= ci.data.labels.length; i++) {
								var y = 0;
								nb = 0;
								for (var j = 0; j <= ci.data.datasets.length - 1; j++) {
									if (!(ci.data.datasets[j] === undefined) && !(ci.data.datasets[j].hidden === undefined) && !ci.data.datasets[j].hidden && !(ci.data.datasets[j].data[i] === undefined)){
										y += ci.data.datasets[j].data[i];
										nb++;
									}
								}
								y = parseInt(y/nb);
								ci.data.datasets[ci.data.datasets.length - 1].data[i] = y;
								ci.data.datasets[ci.data.datasets.length - 1].hidden=true;

							}
							ci.update();
						},
		                labels: {
		                    fontSize: 20,
		                }
		            },
		            scales: {
		                yAxes: [{
		                    ticks: {
		                        display:false,
		                        beginAtZero:true
		                    }
		                }],
		                xAxes: [{
		                    ticks: {
		                        autoSkip: true
		                    }
		                }]
		            }         
		        }
		    });
		    $('#emi').attr('value', this.lambdaEmiMin);
		    $('#exci').attr('value', this.lambdaExciMin);
		}
		GraphObject.prototype.addAC = function(a, c, ac) {
			this.ac.push({"a":a, "c":c, "ac":ac});
		};
		GraphObject.prototype.getImg = function() {
			return this.myChart.toBase64Image();
		};
		/**
		 *	return number of points
		 *	@return {int}	number of points
		 */
		GraphObject.prototype.getNb = function() {
			return this.nbData;
		};
		/**
		 *	return graph step
		 *	@return {int}	graph step
		 */
		GraphObject.prototype.getStep = function() {
			return this.stepGraph;
		};
		/**
		 *	return true if graph is empty
		 *	@return {boolean}	state of graph
		 */
		GraphObject.prototype.isEmpty = function() {
			return (this.myChart.data.datasets[0].data.length == 0);
		};
		GraphObject.prototype.increment = function() {
			if (this.type == 1) {
				$('#emi').attr('value', Number(this.lambdaEmiMin)+this.nbData*this.stepGraph);
			}
			else $('#exci').attr('value', Number(this.lambdaExciMin) + this.nbData*this.stepGraph);
		};
		/**
		 *	Calculate an average from visibles lines on the graph
		 */
		GraphObject.prototype.setAverage = function() {
			//number of lines
			var nb = 0;
			//for each point on the graph
			for (var i = 0; i <= this.myChart.data.labels.length; i++) {
				//y will stock average
				var y = 0;
				//set number of lines to 0
				nb = 0;
				//for each dataset, check if line is visible, and so add value to average, and increment number of lines
				for (var j = 0; j <= this.myChart.data.datasets.length - 1; j++) {
					if (!(this.myChart.data.datasets[j] === undefined) && !(this.myChart.data.datasets[j].hidden === undefined) && !this.myChart.data.datasets[j].hidden && !(this.myChart.data.datasets[j].data[i] === undefined)){
						y += this.myChart.data.datasets[j].data[i];
						nb++;
					}
				}
				//calculate the average (total/number of lines)
				y = parseInt(y/nb);
				//put average into dataset
				this.myChart.data.datasets[this.myChart.data.datasets.length - 1].data[i] = y;
			}
			this.myChart.update();
		};
		/**
		 *	Add a point to the chart. We can't have lambda values, so we use auto increment
		 *	@param {int} yAxis value to put in the graph
		 *	@param {int} data dataset into put the value (by default, set to 0 and function will automatically add value in the first disponible place)
		 */
		GraphObject.prototype.addPoint = function(yAxis, data) {
			var datasetToModify = this.myChart.data.datasets[data];
		    //if selected dataset doesn't exsist, quit method
		    var exist = false;
		    if (datasetToModify === undefined)
		        return;
		    //if selected dataset is complete, increment to switch to next dataset
		    for(;;)
		    	if (this.myChart.data.datasets[data].data.length > parseInt(((this.type == 1)?(this.lambdaEmiMax - this.lambdaEmiMin):(this.lambdaExciMax - this.lambdaExciMin))/this.stepGraph)-1){
		    		data++;
		    	}
		    	else
		    		break;
		    //set y value
		    this.myChart.data.datasets[data].data.push(yAxis);
		    this.nbData++;
		    //recalculate average
		    this.setAverage();
		    //update
		    this.myChart.update();
		    //alert(typeof this.myChart.data.datasets[this.myChart.data.datasets.length-2].data[this.myChart.data.datasets[this.myChart.data.datasets.length-2].data.length-1]);
		    if(!(this.myChart.data.datasets[this.multiScan-1].data[this.myChart.data.labels.length-1] === undefined)) {
		    	angular.element(document.getElementById('graph')).scope().stop();
		    }
		}
		/**
		 *	Erase all points on graph
		 */
		GraphObject.prototype.clearGraph = function() {
			//for each dataset, set y tab to empty tab
		    this.myChart.data.datasets.forEach(function(element){
		    	element.data=[];
		    });
		    this.nbData = 0;
		    $('#exci').attr('value', this.lambdaEmiMin);
		    $('#exci').attr('value', this.lambdaExciMin);
		    //update
		    this.myChart.update();
		}
		/**
		 *	Return a CSV formatted String with X values, an each Y dataset
		 */
		GraphObject.prototype.getDataCSV = function() {
			//first column is the wavelength, lambda
		    var ret = "Lambda";
		    alert(this.ac);
		    //for each set of datas, set label as first case of columns
		    this.myChart.data.datasets.forEach(function(element){
		        ret += ";"+element.label;
		    });
		    ret += ($('#choiceA').is(':checked'))?';A/C':($('#choiceAC').is(':checked'))?';A':' ';
		    //ret+=($('#choiceA').is(':checked'))?";A":($('#choiceC').is(':checked'))?";C":";A/C";
		    //indentation
		    ret += "\n";
		    //for each label on X axis, add data of each dataset at this X coordinate
		    for (var i = 0; i < this.myChart.data.labels.length; i++) {
		        //first column, wavelength
		        ret += this.myChart.data.labels[i];
		        //for each set of data, add value in wright column
		        this.myChart.data.datasets.forEach(function(element){
		            //if value isn't define, we return a blank, for the syntax
		            ret += (element.data[i] === undefined)? "; ":(element.hidden)?"; ":";"+element.data[i];
		        });
		        // ret+=";"+this.ac[i].c;
				ret+=(typeof this.ac[i] === ';undefined')?undefined:($('#choiceA').is(':checked'))?";"+this.ac[i].ac:($('#choiceAC').is(':checked'))?";"+this.ac[i].a:" ";
		        //indentationtion
		        ret+="\n";
		    }

		    return ret;
		}
		/**
		 *	Return a JCAMP-DX formatted String, with X values, and only y average, because in JDX, we can't save more than one line 
		 */
		GraphObject.prototype.getDataJDX = function() {
			var d=new Date();
    		var ret = "##TITLE= spectrofluorescence\n"+
		              "##JCAMP-DX= 5.00\n"+
		              "##OWNER= UBS\n"+
		              "##DATA TYPE= FLORESCENCE SPECTRUM\n"+
		              "##DATA CLASS= PEAK TABLE\n"+
		              "##DATE="+d.getDay()+"."+d.getMonth()+"."+(d.getFullYear()-2000)+"\n"+
		              "##TIME="+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds()+"\n"+
		              "##ORIGIN= Université Bretagne Sud, salle F091\n"+
		              "##XUNITS=Nanometers\n"+
		              "##YUNITS=Relative Luminescence\n"+
		              "##NPOINTS="+this.myChart.data.labels.length+"\n"+
		              "##XFACTOR=1\n"+
		              "##YFACTOR=1\n"+
		              "##XYDATA= (XY..XY) \n";
		    for (var i = 0; i < this.myChart.data.labels.length; i++) 
		    	ret += this.myChart.data.labels[i]+","+this.myChart.data.datasets[this.myChart.data.datasets.length -1].data[i]+";\n";
			ret+= "##END=";
			return ret;
		};
		graph.initialized=true;
	}
}