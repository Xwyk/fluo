﻿//module named fluo
var fluoApp = angular.module('fluo', []);
//adding progress bar controller
fluoApp.controller('progressBarCtrl', function($scope){
	//associating progress bar elements
	$scope.progC = document.getElementById('indicChannelC');
	$scope.progA = document.getElementById('indicChannelA');
	$scope.progAC = document.getElementById('indicChannelAC');
	$scope.exci = $('#exci');
	$scope.emi = $('#emi');


	actualizeAC();
	
	/**
	 * set new value for a lambda (exci or emi)
	 * @param {string} 	toSet 	lambda input to set
	 * @param {int} 	value 	value to set
	 */
	$scope.setLambda = function(toSet, value){
		//check if value is valid
		if (value >= 0 && value <=999)
			if (toSet == 'exci')
				$scope.exci.attr('value', value);
			else if (toSet == 'emi')
				$scope.emi.attr('value', value);
			else
				console.log("module.js/setLambda : inexpected value for toSet : "+toSet);
		else
			console.log("module.js/setLambda : inexpected value for value : "+value);
	}
	/**
	 * set new value for a progress bar (A or C), and call actualizeAC
	 * @param {string} 	toSet 	progress bar to set
	 * @param {int} 	value 	value to set to progress bar
	 */
	$scope.setProg = function(toSet, value){
		//we set A or C if correct call to function
		if (value >= 0 && value <= 100)
			if (toSet=="A"){
				$scope.progA.style.width=value+"%";
				$scope.progA.style.backgroundColor=(value > 75)?"rgba(219,0,0,0.6)":"rgba(0,219,0,0.6)";
			}
			else if (toSet=="C"){
				$scope.progC.style.width=value+"%";
				$scope.progC.style.backgroundColor=(value > 75)?"rgba(219,0,0,0.6)":"rgba(0,219,0,0.6)";
			}
			else
				console.log("module.js/setProg : inexpected value for toSet : "+toSet);
		else{
			if (toSet=="A")
				$scope.progA.style.width=0+"%";
			else if (toSet=="C")
				$scope.progC.style.width=0+"%";
			console.log("module.js/setProg : inexpected value for value : "+value);
		}
		actualizeAC();
	}

	$scope.setProg("A",Math.log10(41));
		$scope.setProg('A', 72);
	$scope.setProg('C', 80);
	/**
	 * Calculate the ration between A and C and set the A/C progress bar value
	 */
	function actualizeAC(){
		var ratio = Math.round(($scope.progA.style.width.substring(0, $scope.progA.style.width.length-1)/$scope.progC.style.width.substring(0, $scope.progC.style.width.length-1))*100)/100;
		$scope.progAC.style.width=(ratio > 100)?'100%':ratio+'px';
		$scope.progAC.style.backgroundColor=($scope.progAC.style.width > 75)?"rgba(219,0,0,0.6)":"rgba(0,219,0,0.6)";
	}
});
//adding buttons controller
fluoApp.controller('buttonsCtrl', function($scope){
	var graph;
	document.getElementById('graphe').style.visibility="hidden";
	var timeoutID;
	var intervalID = setInterval(getOnlyValues, 500);

	/**
	 *	Check if button is enable, and, disable it
	 *	@param {int} 	id 		button id to check
	 */
	var disable = function(id){
		if (!($(id).hasClass('disabled'))) {
			$(id).addClass('disabled');	
		}
	}
	/**
	 *	Check if button is disable, and, enable it
	 *	@param {int} 	id 		button id to check
	 */
	var enable = function(id){
		if (($(id).hasClass('disabled'))) {
			$(id).removeClass('disabled');	
		}
	}
	/**
	 * save datas in a .CSV or .JDX format
	 * @param {int} 	mode 	select csv(0) or jdx(1)
	 */
	$scope.save = function(mode){
		var type = mode; 
		var data;
		switch(type){
			case 0:
				data = graph.getDataJDX();
			break;
			case 1:
				data = graph.getDataCSV();
			break;
			default:
				return;
			break; 
		}
		//formatted string (csv datas)
		//add a new element with a balise 'a' in webpage, to download this string
		var download = document.createElement('a');
		//set attributes of element
		download.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(data));
		download.setAttribute('download', (mode==0)?"results.jdx":"results.csv");
		//don't let this element visible
		download.style.display = 'none';
		//add at the end of document
		document.body.appendChild(download);
		//auto click
		download.click();
		//remove from document
		document.body.removeChild(download);
	};
	$scope.getNb = function(){
		return graph.getNb();
	}
	$scope.getStep = function(){
		return graph.getStep();
	}

	$scope.average = function(){
		graph.setAverage();
	};

	$scope.addPoint = function (y, dataset){
		graph.addPoint(y, dataset);
	}

	$scope.clearGraph = function (){
		graph.clearGraph();
		Materialize.toast('Graphe effacé', 4000, 'rounded');
	}
	$scope.isEmpty = function(){
		return graph.isEmpty();
	}
	$scope.increment = function(){
		graph.increment();		
	}
	$scope.addAC = function(a,c,ac){
		graph.addAC(a,c,ac);
	}

	$scope.configure = function(){
        PurePopup.prompt({
            title: 'Configurer les valeurs',
            buttons: {
                okButton: 'Continuer',
                cancelButton: 'Annuler'
            },
            inputs: {
                spectre: 'Spectre : ',
                freq: 'Fréquence : ',
                step: 'Pas : ',
                multiscan: 'Multiscan : </label><input type="number" min="1" max="99" value="1" ',
                lambdaExciMin: 'λ excitation LB: </label><input type="number" min="0" max="999" value="0" ',
                lambdaEmiMin: 'λ émission LB: </label><input type="number" min="0" max="999" value="0" ',
                lambdaExciMax: 'λ excitation LH: </label><input type="number" min="0" max="999" value="0" ',
                lambdaEmiMax: 'λ émission LH: </label><input type="number" min="0" max="999" value="0" '
            }
        }, function(result) {
            if (result.confirm == 'okButton') {
            	if ((!( typeof result.lambdaEmiMin === 'undefined' && typeof result.lambdaEmiMax === 'undefined' && typeof result.spectre === 'undefined' && typeof result.lambdaExci === 'undefined' && typeof result.step === 'undefined' && typeof result.freq === 'undefined' && typeof result.lambdaEmiMin === 'undefined' && typeof result.lambdaEmiMax === 'undefined' && typeof result.multiscan === 'undefined')) && (result.spectre == 1 || result.spectre == 2) && (result.step == 1/4 || result.step == 1/2 || result.step == 1 || result.step == 2 || result.step == 5) && (result.freq == 4 || result.freq == 2 || result.freq == 1 || result.freq == 1/2 || result.freq == 1/5) && (result.lambdaEmiMin >= 0 && result.lambdaEmiMin <= 999) && (result.lambdaEmiMax >= 0 && result.lambdaEmiMax <= 999) && (Number(result.lambdaEmiMin) <= Number(result.lambdaEmiMax)) && (result.lambdaExciMin >= 0 && result.lambdaExciMin <= 999) && (result.lambdaExciMax >= 0 && result.lambdaExciMax <= 999) && (Number(result.lambdaExciMin) <= Number(result.lambdaExciMax)) && (result.multiscan >=1) && (result.multiscan <=99) ) {
            		graph = new GraphObject(result.lambdaEmiMin, result.lambdaEmiMax, result.lambdaExciMin, result.lambdaExciMax,result.step, result.freq, result.multiscan, result.spectre);
					$('#exci').attr('value', result.lambdaExci);
					Materialize.toast('Graphe prêt', 4000, 'rounded');
           			document.getElementById('graphe').style.visibility="visible";
           			enable('#delBtn');
           			enable('#saveBtn');
           			enable('#playBtn');
           			disable('#pauseBtn');
           			enable('#configBtn');
            		graph.insert();
            		$('#multi').attr('value', result.multiscan);
            		$('#step').attr('value', result.step);
            		$('#freq').attr('value', result.freq);
            		$('#spectre').attr('value', (result.spectre == 1)?'Emission':'Excitation');
            		$('#llexci').attr('value', result.lambdaExciMin);
            		$('#hlexci').attr('value', result.lambdaExciMax);
            		$('#llemi').attr('value', result.lambdaEmiMin);
            		$('#hlemi').attr('value', result.lambdaEmiMax);
            	}          	
            	else{
            		PurePopup.alert({title: 'Erreur de configuration du graphe. Vérifiez les valeurs et leur syntaxe'});
            	}
            } else if (result.confirm == 'cancelButton') {
                
        
                
            } else if (result.confirm == 'noActionCancel') {
                // nothing to do
            }
            
        });

	}
	/**
	 *	enable an interval, so call method 'getFromArduino' every x seconds, according to graph frequency
	 *	enable and disable buttons
	 */
	$scope.start = function(){
		if (!(typeof graph === 'undefined') && typeof timeoutID === 'undefined') {
			timeoutID = setInterval(getFromArduino, graph.frequency*1000);
			disable('#saveBtn');
			disable('#delBtn');
			disable('#configBtn');
			disable('#playBtn');
			enable('#pauseBtn');
			Materialize.toast('Acquisition : ON', 4000, 'rounded');
			clearInterval(intervalID);

		}
	}
	/**
	 *	disable interval
	 *	enable and disable buttons
	 */
	$scope.stop = function(){
		if (!(typeof timeoutID==='undefined') && !(typeof graph === 'undefined')){
			clearInterval(timeoutID);
			timeoutID = undefined;
			enable('#saveBtn');
			enable('#delBtn');
			enable('#configBtn');
			enable('#playBtn');
			disable('#pauseBtn');
			Materialize.toast('Acquisition : OFF', 4000, 'rounded');
			intervalID = setInterval(getOnlyValues, 500);
		}
	}

});
