/*
 * PurePopup by dFelinger
 * https://github.com/dFelinger/PurePopup
 */ 
;(function() {
    'use strict';
    
    var Popup = function() {
        // this.el = typeof el === 'object' ? el : document.getElementById(el);

        // For check current popup type
        this.type = 'alert';
        
        // Set default params
        this.params = {};
        this.setParams();
        
        this.wrap = document.createElement('div');
        this.wrap.id = 'purePopupWrap';
        document.body.appendChild(this.wrap);
        this.wrap.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            if (e.target == this.wrap) this.close('noActionCancel');

            // TODO: settings: close on click
            if (e.target.className.indexOf('purePopupButton') != -1) this.close(e.target.className.match(/_(.*)_/)[1]);
        }.bind(this));
    }
    
    Popup.prototype.setParams = function (params, callback) {
        this.params.title = document.title;
        this.params.callback = null;
        this.params.buttons = (this.type == 'alert') ? {ok: 'Ok'} : {ok: 'Ok', cancel: 'Cancel'};
        this.params.inputs = {name: 'Please, enter your name'};

        if (params) {
            if (typeof params == 'object') {
                params = params;
                if (callback && typeof callback == 'function') params.callback = callback;
            } else if (typeof params == 'function') {
                params = {callback: params};
            }
        } else params = {};

        for (var p in params) if (this.params.hasOwnProperty(p)) this.params[p] = params[p];
    }

    Popup.prototype.show = function () {
        this.wrap.className = 'open';
        setTimeout(function(){
            this.wrap.className = 'open pop';
        }.bind(this), 20);
    }

    Popup.prototype.close = function (confirm) {
        this.wrap.className = 'open';
        setTimeout(function() {
            this.wrap.className = '';
            var result = {confirm: confirm};
            
            var inputs = this.wrap.querySelectorAll('input, select'); 
            //inputs.push(this.wrap.getElementsByTagName("select"));
            for (var i = inputs.length; --i >= 0;)
                result[inputs[i].name] = inputs[i].value; 

            if (this.params.callback) this.params.callback.call(this, result);
        }.bind(this), 300);
    }

    Popup.prototype.alert = function (p, c) {
        this.type = 'alert';
        this.setParams(p, c);
        
        var buttonsHtml = '';
        for (var i in this.params.buttons) buttonsHtml += '<span class="purePopupButton _'+i+'_">'+this.params.buttons[i]+'</span>';

        this.wrap.innerHTML = '<div>'+
                                '<div>'+
                                    '<div class="purePopupTitle">'+this.params.title+'</div>'+
                                    buttonsHtml+
                                '</div>'+
                               '</div>';
        this.show();
    }
    
    Popup.prototype.confirm = function (p, c) {
        this.type = 'confirm';
        this.setParams(p, c);
        
        var buttonsHtml = '';
        for (var i in this.params.buttons) buttonsHtml += '<span class="purePopupButton _'+i+'_">'+this.params.buttons[i]+'</span>';

        this.wrap.innerHTML = '<div>'+
                                '<div>'+
                                    '<div class="purePopupTitle">'+this.params.title+'</div>'+
                                    buttonsHtml+
                                '</div>'+
                               '</div>';
        this.show();
    }
    
    Popup.prototype.prompt = function (p, c) {
        this.type = 'prompt';
        this.setParams(p, c);
        
        var inputsHtml = '', tabIndex = 0;
        inputsHtml+='<div style="float: left; width: 45%">'
        var b = false;
        var c = false;
        for (var i in this.params.inputs) {
        if(this.params.inputs[i].substring(0,4) == "Pas ")
                inputsHtml += '<label for="purePopupInputs_'+i+'">Pas</label>'+
                                '<select name="'+i+'" id="select_step" name="'+i+'" tabindex="'+(tabIndex++)+'"class="browser-default">'+
                                '<option value="0.25">0.25nm</option>'+
                                '<option value="0.5">0.5nm</option>'+
                                '<option value="1" selected>1nm</option>'+
                                '<option value="2">2nm</option>'+
                                '<option value="5">5nm</option>'+
                              '</select>';
                            
            else if(this.params.inputs[i].substring(0,4) == "Fréq")
                inputsHtml += '<label for="purePopupInputs_'+i+'">Fréquence d\'actualisation</label>'+
                                '<select name="'+i+'" id="select_step" name="'+i+'" tabindex="'+(tabIndex++)+'"class="browser-default">'+
                                '<option value="0.2">0.2Hz</option>'+
                                '<option value="0.5">0.5Hz</option>'+
                                '<option value="1" selected>1Hz</option>'+
                                '<option value="2">2Hz</option>'+
                                '<option value="5">5Hz</option>'+
                              '</select>';
            else if (this.params.inputs[i].substring(0,4) == "Spec") 
                inputsHtml += '<label for="purePopupInputs_'+i+'">Type de spectre</label>'+
                                '<select name="'+i+'" id="select_step" name="'+i+'" tabindex="'+(tabIndex++)+'"class="browser-default">'+
                                '<option value="1">Spectre d\'émission</option>'+
                                '<option value="2">Spectre d\'excitation</option>'+
                              '</select>';
            else
                inputsHtml += '<label for="purePopupInputs_'+i+'">'+this.params.inputs[i]+' id="purePopupInputs_'+i+'" name="'+i+'" tabindex="'+(tabIndex++)+'">';
            if (tabIndex >= 4 && !b) {
                inputsHtml+='</div><div style="float: right; width: 45%"><div style="float: left; width: 45%">'
                b= true;
            }
            if (tabIndex >= 6 && !c) {
                inputsHtml+='</div><div style="float: right; width: 45%">'
                c= true;
            }
        }

        
        inputsHtml+='</div></div>'
        var buttonsHtml = '';
        for (var i in this.params.buttons) buttonsHtml += '<span class="purePopupButton _'+i+'_">'+this.params.buttons[i]+'</span>';
        this.wrap.innerHTML = '<div>'+
                                '<div>'+
                                    '<div class="purePopupTitle">'+this.params.title+'</div>'+
                                    inputsHtml+
                                    buttonsHtml+
                                    
                                '</div>'+
                               '</div>';
        this.show();
    }
    
    window.PurePopup = new Popup();
}());