var url='http://172.17.96.72/'
/*$.ajaxSetup({
	error: function(x, e){
		if (x.status == 0) {
			alert("offline");
		}else if (x.status == 404) {
			alert("not found");
		}else if (x.status == 500) {
			alert("Internal errror");
		}else if (e == 'parsererror') {
			alert("error parsing");
		}else if (e == 'timeout') {
			alert("timeout");
		}
		else("fdp");
	}
})*/
/**
 * make a HTTP request to Arduino webserver, and return result
 * @return {string} 	JSON 	formatted string
 */
function getFromArduino(){
	var ret;
	//make GET HTTP request to Arduino at port 80, and set response to JSON type
	$.ajax({
		url: url+"?scan",
		type: 'GET',
		dataType: 'json',
		success: callback,
		error: function(res, status, error){
			//if error, alert user
			alert("Erreur de connexion");
		}
	});
}
/**
 *	make http request to arduino webserver to get only sensors values, without ID
 */
function getOnlyValues(){
	var ret;
	$.ajax({
		url:url+"?onlyValues",
		dataType:'json',
		success: function(res, status){
			console.log(res);
			angular.element(document.getElementById('progress')).scope().setProg("A",(res[res.length-1].a == 0)?0:Math.log10(res[res.length-1].a)*100/Math.log10(1024));
    		angular.element(document.getElementById('progress')).scope().setProg("C",(res[res.length-1].c == 0)?0:Math.log10(res[res.length-1].c)*100/Math.log10(1024));
		}
	})
}