﻿/**
 * synchronise actual values and displayed values from JSON object
 */
var dernierRang=0;
function callback(data, status){
 	//stop if object don't contains data
    if (data.length == 0)
        return
    //set progress bars to the last point in data object
    angular.element(document.getElementById('progress')).scope().setProg("A",Math.log10(data[data.length-1].a)*100/Math.log10(1024));
    angular.element(document.getElementById('progress')).scope().setProg("C",Math.log10(data[data.length-1].c)*100/Math.log10(1024));
    //for each data
    for (var i = 0; i < data.length; i++) {
    	//if graph is empty, add point and check index of data object
    	if (angular.element(document.getElementById('graph')).scope().isEmpty()){
    		angular.element(document.getElementById('graph')).scope().addPoint(($('#choiceA').is(':checked'))?data[i].a:($('#choiceC').is(':checked'))?data[i].c:data[i].a/data[i].c, 0);
    		console.log('1');
    		dernierRang = (data[i].id == 65535)?-1:data[i].id;	
    	}
    	//else if current index equals to last index +1, set value and increment
    	else if (data[i].id == dernierRang+1) {
    		console.log('2');
    		angular.element(document.getElementById('graph')).scope().addPoint(($('#choiceA').is(':checked'))?data[i].a:($('#choiceC').is(':checked'))?data[i].c:data[i].a/data[i].c, 0);
    		dernierRang = data[i].id
    	}
    	//else add blank points in the graph and alert user to prevent error
    	else{
    		for (var j = dernierRang; j < data[i].id-1; j++) {
    			angular.element(document.getElementById('graph')).scope().addPoint(0, 0);
			angular.element(document.getElementById('graph')).scope().addAC(0, 0, 0);
    		}
    		console.log('3');

			Materialize.toast('Problème de communication\nRisque de points maquants', 4000);
    		angular.element(document.getElementById('graph')).scope().addPoint(($('#choiceA').is(':checked'))?data[i].a:($('#choiceC').is(':checked'))?data[i].c:data[i].a/data[i].c, 0);
    		dernierRang = data[i].id;
    	}
	angular.element(document.getElementById('graph')).scope().addAC(data[i].a, data[i].c, (data[i].c == 0)?0:(data[i].a/data[i].c));
    	console.log(data[i].id+" "+data[i].a+" "+data[i].c);
    }
    //set emission label to last value in data list
    angular.element(document.getElementById('graph')).scope().increment();
 }